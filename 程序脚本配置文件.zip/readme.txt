1、下载序列应全放入strain_file文件夹

2、命令行 python crisprcas.py -cas1 x -class1r x -class2r x -class1e x  -class2e x -neighbor x -prot_len x

-cas1 x 调整cas1阈值，x默认为10
-class1r x	调整识别阶段class1蛋白阈值，x默认1e-10
-class2r x 调整识别阶段class2蛋白阈值，x默认1e-10
-class1e x 调整发掘阶段class1蛋白阈值，x默认1e-10
-class2e x 调整发掘阶段class2蛋白阈值，x默认1e-10
-neighbor x 调整邻域长度，x默认为20000，与程序第一步序列长度筛选相关联
-prot_len x 调整candidate蛋白大小，x默认为800

3、依赖软件
Python3.7+、Prokka、Hmmer、Minced