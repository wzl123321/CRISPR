import os
import re
import shutil
import sys

address = str(os.getcwd()) + '/'
if '-cas1' in sys.argv[1::2]:
    cas1_threshold = float(sys.argv[sys.argv.index('-cas1') + 1])
else:
    cas1_threshold = 10
if '-class1r' in sys.argv[1::2]:
    class1r_threshold = float(sys.argv[sys.argv.index('-class1r') + 1])
else:
    class1r_threshold = 1e-10
if '-class2r' in sys.argv[1::2]:
    class2r_threshold = float(sys.argv[sys.argv.index('-class2r') + 1])
else:
    class2r_threshold = 1e-10
if '-class1e' in sys.argv[1::2]:
    class1e_threshold = float(sys.argv[sys.argv.index('-class1e') + 1])
else:
    class1e_threshold = 1e-10
if '-class2e' in sys.argv[1::2]:
    class2e_threshold = float(sys.argv[sys.argv.index('-class2e') + 1])
else:
    class2e_threshold = 1e-10
if '-neighbor' in sys.argv[1::2]:
    neighbor_threshold = int(sys.argv[sys.argv.index('-neighbor') + 1])
else:
    neighbor_threshold = 20000
if '-prot_len' in sys.argv[1::2]:
    prot_len = int(sys.argv[sys.argv.index('-prot_len') + 1])
else:
    prot_len = 800

print('Running Part1...')
address2 = address + 'strain_file/'
address3 = address + 'trim_strain_file/'
try:
    os.mkdir(address3)
except FileExistsError:
    pass
filelist = os.listdir(address2)
for file in filelist:
    with open(address2 + file) as fb:
        content = fb.readlines()
    filename = file.split('.fa')[0]
    with open(address3 + filename + '.fa', 'w') as fb:
        all = ''
        for line in content:
            if '>' in line:
                title = filename
                fb.write(all + '\n')
                all = '>' + title + '\n'
            else:
                line = line.rstrip('\n')
                all += line
        fb.write(all)
        fb.write('\n')
#####################################################################
address2 = address + 'trim_strain_file/'
try:
    os.mkdir('strain_fa/')
except FileExistsError:
    pass
file_list = os.listdir(address2)
for file in file_list:
    with open(address2 + file) as fb:
        content = fb.readlines()
    i = 0
    while i < len(content):
        if '>' in content[i]:
            if len(content[i + 1]) > neighbor_threshold:
                title = content[i].lstrip('>').split()[0]
                with open('strain_fa/' + title + '.fa', 'w') as fb1:
                    fb1.write(content[i])
                    fb1.write(content[i + 1])
        i += 1
#####################################################################
os.system('bash script1')
####################################################################
print('Running Part2...')
address2 = address + 'strain_gff/'
address3 = address + 'correct_gff_file/'
try:
    os.mkdir(address3)
except FileExistsError:
    pass
gff_file = os.listdir(address2)
for file in gff_file:
    name = file.rstrip('.gff')
    with open(address3 + name + '.gff', 'w') as fb1:
        with open(address2 + name + '.gff') as fb2:
            content = fb2.read()
        gff = re.search('##gff-version 3\n(.*?)\n##FASTA', content, re.S)
        gff = gff.group(1).split('\n')
        n = 1
        for line in gff:
            line = line + '\n'
            if '#' in line:
                fb1.write(line)
            else:
                switch = line.split('\t')[2]
                if switch == 'CDS':
                    gene_id = re.search('\tID=(.*?);', line)
                    title = line.split('\t')[0]
                    line_new = line.replace(gene_id.group(1), title + '_' + str(n))
                    n += 1
                    fb1.write(line_new)
                else:
                    fb1.write(line)
#############################################################################
address2 = address + 'strain_faa/'
address3 = address + 'trim_strain_faa/'
os.mkdir(address3)
file_list = os.listdir(address2)
for file_name in file_list:
    file = address2 + file_name
    with open(address3 + file_name, 'w') as fb_1:
        with open(file) as fb:
            lines = fb.readlines()
        all = ''
        for line in lines:
            if '>' in line:
                if all != '':
                    fb_1.write(all + '\n')
                all = line
            else:
                line = line.rstrip('\n')
                all += line
        fb_1.write(all)
        fb_1.write('\n')
address2 = address + 'trim_strain_faa/'
address3 = address + 'ctt_strain_faa/'
os.mkdir(address3)
file_list = os.listdir(address2)
for file in file_list:
    with open(address2 + file) as fb1:
        content1 = fb1.readlines()
    with open(address3 + file, 'a') as fb2:
        n = 1
        for line in content1:
            if '>' in line:
                file_name = file.rstrip('.faa')
                line = '>' + file_name + '_' + str(n) + '\n'
                n += 1
                fb2.write(line)
            else:
                fb2.write(line)

###################################################################################
print('Running Part3...')
crispr_file = address + 'minced_result/'
crispr_file_list = os.listdir(crispr_file)
file_list = os.listdir(address + 'strain_fa/')
try:
    os.mkdir(address + 'crispr_faa/')
except FileExistsError:
    pass
crispr_title = []
for file in crispr_file_list:
    file_size = os.path.getsize(crispr_file + file)
    if file_size != 0:
        title = file.rstrip('.crispr')
        file = title + '.faa'
        shutil.copy(address + 'ctt_strain_faa/' + file, address + 'crispr_faa/')

###################################################################################
os.system('bash script2')
###################################################################################
address2 = address + 'cas1_faa'
try:
    os.mkdir(address2)
except FileExistsError:
    pass
with open(address + 'cas1_hmmresult') as fb:
    content = fb.readlines()
title_list = []
for line in content:
    if '#' not in line:
        title = line.split()[0]
        strain = title[:title.rfind('_')]
        title_list.append(strain)
unique_list = list(set(title_list))
for file in unique_list:
    file = file + '.faa'
    shutil.copy(address + 'ctt_strain_faa/' + file, address2)
###################################################################################
print('Running Part4...')
crispr_address = address + 'minced_result/'
seq_address = address + 'crispr_faa/'
crispr_file_list = os.listdir(crispr_address)
seq_file_list = os.listdir(seq_address)
target_1_list = []
target_2_list = []
dic_crispr = {}
crispr_list = os.listdir(seq_address)
for crispr in crispr_list:
    crispr_file_name = crispr.strip('.faa')
    crispr_file = crispr_address + crispr_file_name + '.crispr'
    with open(crispr_file) as f1:
        content_1 = f1.read()
        key_start = "Sequence"
        key_end = "Time to find"
        com = re.compile(key_start + '(.*?)' + key_end, re.S)
        content_1_1 = com.findall(content_1)
        for i in content_1_1:
            target_1 = re.search(" \\'(.*?)\\'", i)
            target_2 = re.findall("Range: (.*?) - (.*?)\n", i)
            target_1_list.append(target_1.group(1))
            target_2_list.append(target_2)
        n = 0
        for j in target_1_list:
            dic_crispr[j] = target_2_list[n]
            n += 1

dic_num = {}
for seq_file_name in seq_file_list:
    n = 0
    seq_file = seq_address + seq_file_name
    with open(seq_file) as f2:
        content_2 = f2.read()
        target_3 = re.findall(">(.*?)\n(.*)\n", content_2)
        while n < len(target_3):
            dic_num[target_3[n][0].split(' ')[0]] = target_3[n][1]
            n += 1

address2 = address + 'crispr_neighborhood_faa/'
address3 = address + 'correct_gff_file/'
try:
    os.mkdir(address2)
except FileExistsError:
    pass
target_list = []
for target_1 in target_1_list:
    target_2 = dic_crispr[target_1]
    with open(address3 + target_1 + '.gff') as fb:
        content = fb.readlines()
    gff_local_list = []
    average_local_list = []
    gff_content = []
    for temp in content:
        if '#' not in temp:
            if 'minced' not in temp:
                if '\tCDS\t' in temp:
                    gff_content.append(temp)
    for gff_local in gff_content:
        gff_local_first = gff_local.split()[3]
        gff_local_second = gff_local.split()[4]
        gff_local_list.append(int(gff_local_first))
        gff_local_list.append(int(gff_local_second))
        average_local_list.append((int(gff_local_first) + int(gff_local_second)) / 2)
    i = 0
    while i < len(target_2):
        crispr_first = int(target_2[i][0])
        crispr_second = int(target_2[i][1])
        extract_first = int(target_2[i][0]) - neighbor_threshold / 2
        extract_second = int(target_2[i][1]) + neighbor_threshold / 2
        i += 1
        if extract_first < 0:
            extract_first = gff_local_list[0]
        if extract_second > gff_local_list[-1]:
            extract_second = gff_local_list[-1]
        diff_1_list = []
        diff_2_list = []
        for average_local in average_local_list:
            diff_1 = abs(extract_first - average_local)
            diff_2 = abs(extract_second - average_local)
            diff_1_list.append(diff_1)
            diff_2_list.append(diff_2)
        extract_list = []
        for line in gff_content[diff_1_list.index(min(diff_1_list)):diff_2_list.index(min(diff_2_list)) + 1]:
            try:
                extract_title = re.search('\tID=(.*?);', line)
                extract_list.append(extract_title.group(1))
            except AttributeError:
                pass
        with open(address + 'crispr_faa/' + target_1 + '.faa') as fb:
            content = fb.readlines()
        j = 1
        if target_1 in target_list:
            j = target_list.count(target_1) + 1
        with open(address2 + target_1 + '_' + str(j) + '.faa', 'w') as fb1:
            target_list.append(target_1)
            for extract in extract_list:
                k = 0
                while True:
                    if extract in content[k]:
                        fb1.write(content[k])
                        fb1.write(content[k + 1])
                        break
                    k += 1

####################################################################################

cas1_address = address + 'cas1_hmmresult'
seq_address = address + 'cas1_faa/'
seq_file_list = os.listdir(seq_address)
dic_cas1 = {}
cas1_list = []

with open(cas1_address) as fb:
    content = fb.readlines()
for cas1 in seq_file_list:
    for line in content:
        if '#' not in line:
            if cas1.strip('.faa') in line:
                title = line.split()[0]
                evalue = float(line.split()[4])
                if evalue <= cas1_threshold:
                    if title in dic_cas1.keys():
                        if float(dic_cas1[title]) > float(evalue):
                            dic_cas1[title] = evalue
                    else:
                        dic_cas1[title] = evalue

dic_num = {}
for seq_file_name in seq_file_list:
    n = 0
    seq_file = seq_address + seq_file_name
    with open(seq_file) as f2:
        content_2 = f2.read()
        target_3 = re.findall(">(.*?)\n(.*)\n", content_2)
        while n < len(target_3):
            dic_num[target_3[n][0].split(' ')[0]] = target_3[n][1]
            n += 1

address2 = address + 'cas1_neighborhood_faa/'
address3 = address + 'correct_gff_file/'
try:
    os.mkdir(address2)
except FileExistsError:
    pass
target_list = []
for target_1 in dic_cas1.keys():
    title = target_1[:target_1.rfind('_')]
    with open(address3 + title + '.gff') as fb:
        content = fb.readlines()
    gff_local_list = []
    average_local_list = []
    gff_content = []
    for temp in content:
        if '#' not in temp:
            if 'minced' not in temp:
                if '\tCDS\t' in temp:
                    gff_content.append(temp)
    for gff_local in gff_content:
        if target_1 == re.search('\tID=(.*?);', gff_local).group(1):
            cas1_local_first = gff_local.split()[3]
            cas1_local_second = gff_local.split()[4]
        gff_local_first = gff_local.split()[3]
        gff_local_second = gff_local.split()[4]
        gff_local_list.append(int(gff_local_first))
        gff_local_list.append(int(gff_local_second))
        average_local_list.append((int(gff_local_first) + int(gff_local_second)) / 2)

    extract_first = int(cas1_local_first) - neighbor_threshold / 2
    extract_second = int(cas1_local_second) + neighbor_threshold / 2
    if extract_first < 0:
        extract_first = gff_local_list[0]
    if extract_second > gff_local_list[-1]:
        extract_second = gff_local_list[-1]
    diff_1_list = []
    diff_2_list = []
    for average_local in average_local_list:
        diff_1 = abs(extract_first - average_local)
        diff_2 = abs(extract_second - average_local)
        diff_1_list.append(diff_1)
        diff_2_list.append(diff_2)
    extract_list = []
    for line in gff_content[diff_1_list.index(min(diff_1_list)):diff_2_list.index(min(diff_2_list)) + 1]:
        try:
            extract_title = re.search('\tID=(.*?);', line)
            extract_list.append(extract_title.group(1))
        except AttributeError:
            pass
    with open(address + 'cas1_faa/' + title + '.faa') as fb:
        content = fb.readlines()
    j = 1
    if title in target_list:
        j = target_list.count(title) + 1
    with open(address2 + title + '_' + str(j) + '.faa', 'w') as fb1:
        target_list.append(title)
        for extract in extract_list:
            k = 0
            while True:
                if extract in content[k]:
                    fb1.write(content[k])
                    fb1.write(content[k + 1])
                    break
                k += 1

###############################################################################
print('Running Part5...')
address2 = address + 'crispr_neighborhood_faa/'
address3 = address + 'cas1_neighborhood_faa/'
all_intersection = []
crispr_neighborhood_faa_file = os.listdir(address2)
cas1_neighborhood_faa_file = os.listdir(address3)
if len(crispr_neighborhood_faa_file) > len(cas1_neighborhood_faa_file):
    file_list = crispr_neighborhood_faa_file
    switch = 0
else:
    file_list = cas1_neighborhood_faa_file
    switch = 1
if switch == 0:
    temp_address = address2
    temp_address2 = address3
else:
    temp_address = address3
    temp_address2 = address2
temp_list1 = []
temp_list2 = []
title_list = []
for file in file_list:
    title = file.strip('.faa')
    title_list.append(title[:title.rfind('_')])
unique_title_list = list(set(title_list))
os.system('mkdir intersection_file_1')
os.system('mkdir intersection_file_2')
for title in unique_title_list:
    os.system('cat ' + temp_address + title + '* >> intersection_file_1/' + title + '.faa')
    os.system('cat ' + temp_address2 + title + '* >> intersection_file_2/' + title + '.faa')
with open('intersection.faa', 'w') as fb1:
    for title in unique_title_list:
        with open('intersection_file_1/' + title + '.faa') as fb:
            content1 = fb.readlines()
        with open('intersection_file_2/' + title + '.faa') as fb:
            content2 = fb.readlines()
        for seq in [i for i in content1 if i in content2]:
            fb1.write(seq)

######################################################################################
os.system('bash script3')
######################################################################################

switch = ['class1', 'class2']
class1_i_list = []
class1_iii_list = []
class1_iv_list = []
class2_ii_list = []
class2_v_list = []
class2_vi_list = []
for temp in switch:
    with open(address + temp + '_intersection_hmmresult') as fb:
        content = fb.readlines()
    dic_evalue_marker = {}
    if temp == 'class1':
        threshold = class1r_threshold
    if temp == 'class2':
        threshold = class2r_threshold
    for line in content:
        if '#' not in line:
            title = line.split()[0]
            marker = line.split()[2]
            evalue = line.split()[4]
            if float(evalue) <= threshold:
                if title in dic_evalue_marker.keys():
                    if float(dic_evalue_marker[title].split(',')[0]) > float(evalue):
                        dic_evalue_marker[title] = evalue + ',' + marker
                else:
                    dic_evalue_marker[title] = evalue + ',' + marker
    for title in dic_evalue_marker.keys():
        name = title[:title.rfind('_')]
        marker = dic_evalue_marker[title].split(',')[1]
        if 'Cas3' in marker:
            class1_i_list.append(name)
        if 'Cas10' in marker:
            class1_iii_list.append(name)
        if 'Csf1' in marker:
            class1_iv_list.append(name)
        if 'Cas9' in marker:
            class2_ii_list.append(name)
        if 'Cas12' in marker:
            class2_v_list.append(name)
        if 'Cas13' in marker:
            class2_vi_list.append(name)
with open(address + 'class1_I_total', 'w') as fb:
    for line in set(class1_i_list):
        fb.write(line + '\n')
with open(address + 'class1_III_total', 'w') as fb:
    for line in set(class1_iii_list):
        fb.write(line + '\n')
with open(address + 'class1_IV_total', 'w') as fb:
    for line in set(class1_iv_list):
        fb.write(line + '\n')
with open(address + 'class2_II_total', 'w') as fb:
    for line in set(class2_ii_list):
        fb.write(line + '\n')
with open(address + 'class2_V_total', 'w') as fb:
    for line in set(class2_v_list):
        fb.write(line + '\n')
with open(address + 'class2_VI_total', 'w') as fb:
    for line in set(class2_vi_list):
        fb.write(line + '\n')
#####################################################################################

print('Running Part6...')


def sort_key(s):
    re_digits = re.compile(r'(\d+)')
    pieces = re_digits.split(s)
    pieces[1::2] = map(int, pieces[1::2])
    return pieces


module_dic = {}
temp_list = []
dic_intersection = {}
dic_intersection_keys_list = []
with open('intersection.faa') as fb:
    content = fb.readlines()
i = 0
while i < len(content):
    if '>' in content[i]:
        dic_intersection[content[i]] = content[i + 1]
    i += 1
for key in dic_intersection.keys():
    key = key.lstrip('>').strip()
    dic_intersection_keys_list.append(key)
dic_intersection_keys_list.sort(key=sort_key)

for key in dic_intersection_keys_list:
    seq_title = key.lstrip('>').strip()
    seq_name = seq_title[:seq_title.rfind('_')]
    seq_num = seq_title.split('_')[-1]
    if seq_name not in temp_list:
        n = 1
    temp_list.append(seq_name)
    module_name = seq_name + '_' + str(n)
    if module_name not in module_dic.keys():
        module_dic[module_name] = seq_title
    else:
        if seq_title not in module_dic[module_name]:
            if abs(int(seq_num) - int(module_dic[module_name].split()[-1].split('_')[-1])) == 1:
                module_dic[module_name] += ' ' + seq_title
            else:
                n += 1
                module_name = seq_name + '_' + str(n)
                module_dic[module_name] = seq_title

switch = ['class1', 'class2']
crash_list = []
for temp in switch:
    with open(address + temp + '_intersection_hmmresult') as fb:
        content = fb.readlines()
    if temp == 'class1':
        threshold = class1e_threshold
    if temp == 'class2':
        threshold = class2e_threshold
    for line in content:
        if '#' not in line:
            if float(line.split()[4]) <= threshold:
                title = line.split()[0]
                for module in module_dic.keys():
                    for prot in module_dic[module].split():
                        if title == prot:
                            crash_list.append(module)
                            break
for crash in set(crash_list):
    del module_dic[crash]

title_list = []
for module in module_dic.keys():
    for i in module_dic[module].split():
        title_list.append(i)

strain_list = []
with open('candidate_list', 'w') as fb:
    for title in title_list:
        for i in dic_intersection.keys():
            if title in i:
                strain_list.append(title[:title.rfind('_')] + '\n')
    unique_list = list(set(strain_list))
    for title in unique_list:
        fb.write(title)
with open('candidate_seq.faa', 'w') as fb:
    for title in title_list:
        for i in dic_intersection.keys():
            if title in i:
                fb.write(i)
                fb.write(dic_intersection[i])
with open('candidate_protein.faa', 'w') as fb:
    with open('candidate_seq.faa') as fb1:
        content = fb1.readlines()
    i = 0
    while i < len(content):
        if '>' in content[i]:
            seq = content[i + 1]
            if len(seq) >= prot_len:
                fb.write(content[i])
                fb.write(content[i + 1])
        i += 1
